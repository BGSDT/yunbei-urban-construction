/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.registry.client.particle.forge;

import com.mojang.logging.LogUtils;
import dev.architectury.forge.ArchitecturyForge;
import dev.architectury.registry.client.particle.ParticleProviderRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.particle.ParticleFactory;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.client.particle.SpriteProvider;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleType;
import net.minecraft.util.math.random.Random;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

@Mod.EventBusSubscriber(modid = ArchitecturyForge.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ParticleProviderRegistryImpl {
    
    public static final Logger LOGGER = LogUtils.getLogger();
    
    private static final class ExtendedSpriteSetImpl implements ParticleProviderRegistry.ExtendedSpriteSet {
        private final ParticleManager engine;
        private final SpriteProvider delegate;
        
        private ExtendedSpriteSetImpl(ParticleManager engine, SpriteProvider delegate) {
            this.engine = engine;
            this.delegate = delegate;
        }
        
        @Override
        public SpriteAtlasTexture getAtlas() {
            return engine.particleAtlasTexture;
        }
        
        @Override
        public List<Sprite> getSprites() {
            return ((ParticleManager.SimpleSpriteProvider) delegate).f_107406_;
        }
        
        @Override
        public Sprite getSprite(int i, int j) {
            return delegate.getSprite(i, j);
        }
        
        @Override
        public Sprite getSprite(Random random) {
            return delegate.getSprite(random);
        }
    }
    
    private static List<Consumer<ParticleProviderRegistrar>> deferred = new ArrayList<>();
    
    private static <T extends ParticleEffect> void doRegister(ParticleProviderRegistrar registrar, ParticleType<T> type, ParticleFactory<T> provider) {
        registrar.register(type, provider);
    }
    
    private static <T extends ParticleEffect> void doRegister(ParticleProviderRegistrar registrar, ParticleType<T> type, ParticleProviderRegistry.DeferredParticleProvider<T> provider) {
        registrar.register(type, sprites ->
                provider.create(new ExtendedSpriteSetImpl(MinecraftClient.getInstance().particleManager, sprites)));
    }
    
    public static <T extends ParticleEffect> void register(ParticleType<T> type, ParticleFactory<T> provider) {
        if (deferred == null) {
            LOGGER.warn("Something is attempting to register particle providers at a later point than intended! This might cause issues!", new Throwable());
            doRegister(ParticleProviderRegistrar.ofFallback(), type, provider);
        } else {
            deferred.add(registrar -> doRegister(registrar, type, provider));
        }
    }
    
    public static <T extends ParticleEffect> void register(ParticleType<T> type, ParticleProviderRegistry.DeferredParticleProvider<T> provider) {
        if (deferred == null) {
            LOGGER.warn("Something is attempting to register particle providers at a later point than intended! This might cause issues!", new Throwable());
            doRegister(ParticleProviderRegistrar.ofFallback(), type, provider);
        } else {
            deferred.add(registrar -> doRegister(registrar, type, provider));
        }
    }
    
    @SubscribeEvent
    public static void onParticleFactoryRegister(RegisterParticleProvidersEvent event) {
        if (deferred != null) {
            ParticleProviderRegistrar registrar = ParticleProviderRegistrar.ofForge(event);
            // run all deferred registrations
            for (Consumer<ParticleProviderRegistrar> consumer : deferred) {
                consumer.accept(registrar);
            }
            // yeet deferred list - register immediately from now on
            deferred = null;
        }
    }
    
    private interface ParticleProviderRegistrar {
        <T extends ParticleEffect> void register(ParticleType<T> type, ParticleFactory<T> provider);
        
        <T extends ParticleEffect> void register(ParticleType<T> type, ParticleManager.SpriteAwareFactory<T> registration);
        
        static ParticleProviderRegistrar ofForge(RegisterParticleProvidersEvent event) {
            return new ParticleProviderRegistrar() {
                @Override
                public <T extends ParticleEffect> void register(ParticleType<T> type, ParticleFactory<T> provider) {
                    event.registerSpecial(type, provider);
                }
                
                @Override
                public <T extends ParticleEffect> void register(ParticleType<T> type, ParticleManager.SpriteAwareFactory<T> registration) {
                    event.registerSpriteSet(type, registration);
                }
            };
        }
        
        static ParticleProviderRegistrar ofFallback() {
            return new ParticleProviderRegistrar() {
                @Override
                public <T extends ParticleEffect> void register(ParticleType<T> type, ParticleFactory<T> provider) {
                    MinecraftClient.getInstance().particleManager.registerFactory(type, provider);
                }
                
                @Override
                public <T extends ParticleEffect> void register(ParticleType<T> type, ParticleManager.SpriteAwareFactory<T> registration) {
                    MinecraftClient.getInstance().particleManager.registerFactory(type, registration);
                }
            };
        }
    }
}
