/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.registry.client.level.entity.forge;

import dev.architectury.forge.ArchitecturyForge;
import dev.architectury.platform.forge.EventBuses;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;

public class EntityModelLayerRegistryImpl {
    private static final Map<EntityModelLayer, Supplier<TexturedModelData>> DEFINITIONS = new ConcurrentHashMap<>();
    
    static {
        EventBuses.onRegistered(ArchitecturyForge.MOD_ID, bus -> {
            bus.register(EntityModelLayerRegistryImpl.class);
        });
    }
    
    public static void register(EntityModelLayer location, Supplier<TexturedModelData> definition) {
        DEFINITIONS.put(location, definition);
    }
    
    @SubscribeEvent
    public static void event(EntityRenderersEvent.RegisterLayerDefinitions event) {
        for (Map.Entry<EntityModelLayer, Supplier<TexturedModelData>> entry : DEFINITIONS.entrySet()) {
            event.registerLayerDefinition(entry.getKey(), entry.getValue());
        }
    }
}
