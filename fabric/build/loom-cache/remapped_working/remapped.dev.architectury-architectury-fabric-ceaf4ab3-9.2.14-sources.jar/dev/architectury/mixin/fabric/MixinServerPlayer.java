/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.mixin.fabric;

import dev.architectury.event.events.common.PlayerEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.OptionalInt;
import net.minecraft.entity.passive.AbstractHorseEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.screen.NamedScreenHandlerFactory;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;

@Mixin(ServerPlayerEntity.class)
public class MixinServerPlayer {
    @Inject(method = "restoreFrom", at = @At("RETURN"))
    private void restoreFrom(ServerPlayerEntity serverPlayer, boolean bl, CallbackInfo ci) {
        PlayerEvent.PLAYER_CLONE.invoker().clone(serverPlayer, (ServerPlayerEntity) (Object) this, bl);
    }
    
    @Inject(method = "openMenu", at = @At("RETURN"))
    private void openMenu(NamedScreenHandlerFactory menuProvider, CallbackInfoReturnable<OptionalInt> cir) {
        if (cir.getReturnValue().isPresent()) {
            PlayerEvent.OPEN_MENU.invoker().open((ServerPlayerEntity) (Object) this, ((ServerPlayerEntity) (Object) this).currentScreenHandler);
        }
    }
    
    @Inject(method = "openHorseInventory", at = @At("RETURN"))
    private void openHorseInventory(AbstractHorseEntity abstractHorse, Inventory container, CallbackInfo ci) {
        PlayerEvent.OPEN_MENU.invoker().open((ServerPlayerEntity) (Object) this, ((ServerPlayerEntity) (Object) this).currentScreenHandler);
    }
    
    @Inject(method = "doCloseContainer",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/inventory/AbstractContainerMenu;removed(Lnet/minecraft/world/entity/player/Player;)V",
                    shift = At.Shift.AFTER))
    private void doCloseContainer(CallbackInfo ci) {
        PlayerEvent.CLOSE_MENU.invoker().close((ServerPlayerEntity) (Object) this, ((ServerPlayerEntity) (Object) this).currentScreenHandler);
    }
    
    @Inject(method = "triggerDimensionChangeTriggers", at = @At("HEAD"))
    private void changeDimension(ServerWorld serverLevel, CallbackInfo ci) {
        PlayerEvent.CHANGE_DIMENSION.invoker().change((ServerPlayerEntity) (Object) this, serverLevel.getRegistryKey(), ((ServerPlayerEntity) (Object) this).getWorld().getRegistryKey());
    }
}
