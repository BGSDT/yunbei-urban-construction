/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.registry.level.biome.fabric;

import com.google.common.base.Predicates;
import com.google.common.collect.Lists;
import com.mojang.datafixers.util.Either;
import dev.architectury.hooks.level.biome.*;
import dev.architectury.hooks.level.biome.BiomeProperties.Mutable;
import dev.architectury.registry.level.biome.BiomeModifications.BiomeContext;
import net.fabricmc.fabric.api.biome.v1.BiomeModification;
import net.fabricmc.fabric.api.biome.v1.BiomeModificationContext;
import net.fabricmc.fabric.api.biome.v1.BiomeModificationContext.EffectsContext;
import net.fabricmc.fabric.api.biome.v1.BiomeModificationContext.WeatherContext;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectionContext;
import net.fabricmc.fabric.api.biome.v1.ModificationPhase;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.sound.BiomeAdditionsSound;
import net.minecraft.sound.BiomeMoodSound;
import net.minecraft.sound.MusicSound;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.Biome.TemperatureModifier;
import net.minecraft.world.biome.BiomeEffects.GrassColorModifier;
import net.minecraft.world.biome.BiomeParticleConfig;
import net.minecraft.world.biome.SpawnSettings;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.carver.ConfiguredCarver;
import net.minecraft.world.gen.feature.PlacedFeature;
import net.minecraft.world.level.biome.*;
import org.apache.commons.lang3.tuple.Pair;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.BiPredicate;
import java.util.function.Predicate;

import static net.fabricmc.fabric.api.biome.v1.BiomeModificationContext.*;

import GenerationSettingsContext;
import SpawnSettingsContext;

public class BiomeModificationsImpl {
    private static final Identifier FABRIC_MODIFICATION = new Identifier("architectury", "fabric_modification");
    private static final List<Pair<Predicate<BiomeContext>, BiConsumer<BiomeContext, BiomeProperties.Mutable>>> ADDITIONS = Lists.newArrayList();
    private static final List<Pair<Predicate<BiomeContext>, BiConsumer<BiomeContext, BiomeProperties.Mutable>>> POST_PROCESSING = Lists.newArrayList();
    private static final List<Pair<Predicate<BiomeContext>, BiConsumer<BiomeContext, BiomeProperties.Mutable>>> REMOVALS = Lists.newArrayList();
    private static final List<Pair<Predicate<BiomeContext>, BiConsumer<BiomeContext, BiomeProperties.Mutable>>> REPLACEMENTS = Lists.newArrayList();
    
    public static void addProperties(Predicate<BiomeContext> predicate, BiConsumer<BiomeContext, BiomeProperties.Mutable> modifier) {
        ADDITIONS.add(Pair.of(predicate, modifier));
    }
    
    public static void postProcessProperties(Predicate<BiomeContext> predicate, BiConsumer<BiomeContext, BiomeProperties.Mutable> modifier) {
        POST_PROCESSING.add(Pair.of(predicate, modifier));
    }
    
    public static void removeProperties(Predicate<BiomeContext> predicate, BiConsumer<BiomeContext, BiomeProperties.Mutable> modifier) {
        REMOVALS.add(Pair.of(predicate, modifier));
    }
    
    public static void replaceProperties(Predicate<BiomeContext> predicate, BiConsumer<BiomeContext, BiomeProperties.Mutable> modifier) {
        REPLACEMENTS.add(Pair.of(predicate, modifier));
    }
    
    static {
        var modification = net.fabricmc.fabric.api.biome.v1.BiomeModifications.create(FABRIC_MODIFICATION);
        registerModification(modification, ModificationPhase.ADDITIONS, ADDITIONS);
        registerModification(modification, ModificationPhase.POST_PROCESSING, POST_PROCESSING);
        registerModification(modification, ModificationPhase.REMOVALS, REMOVALS);
        registerModification(modification, ModificationPhase.REPLACEMENTS, REPLACEMENTS);
    }
    
    private static void registerModification(BiomeModification modification, ModificationPhase phase, List<Pair<Predicate<BiomeContext>, BiConsumer<BiomeContext, BiomeProperties.Mutable>>> list) {
        modification.add(phase, Predicates.alwaysTrue(), (biomeSelectionContext, biomeModificationContext) -> {
            var biomeContext = wrapSelectionContext(biomeSelectionContext);
            var mutableBiome = wrapMutableBiome(biomeSelectionContext.getBiome(), biomeModificationContext);
            for (var pair : list) {
                if (pair.getLeft().test(biomeContext)) {
                    pair.getRight().accept(biomeContext, mutableBiome);
                }
            }
        });
    }
    
    private static BiomeContext wrapSelectionContext(BiomeSelectionContext context) {
        return new BiomeContext() {
            BiomeProperties properties = BiomeHooks.getBiomeProperties(context.getBiome());
            
            @Override
            public Optional<Identifier> getKey() {
                return Optional.ofNullable(context.getBiomeKey().location());
            }
            
            @Override
            public BiomeProperties getProperties() {
                return properties;
            }
            
            @Override
            public boolean hasTag(TagKey<Biome> tag) {
                return context.hasTag(tag);
            }
        };
    }
    
    private static BiomeProperties.Mutable wrapMutableBiome(Biome biome, BiomeModificationContext context) {
        return new BiomeHooks.MutableBiomeWrapped(
                biome,
                wrapWeather(biome, context.getWeather()),
                wrapEffects(biome, context.getEffects()),
                new MutableGenerationProperties(biome, context.getGenerationSettings()),
                new MutableSpawnProperties(biome, context.getSpawnSettings())
        ) {
        };
    }
    
    private static class MutableGenerationProperties extends BiomeHooks.GenerationSettingsWrapped implements GenerationProperties.Mutable {
        protected final net.fabricmc.fabric.api.biome.v1.BiomeModificationContext.GenerationSettingsContext context;
        
        public MutableGenerationProperties(Biome biome, net.fabricmc.fabric.api.biome.v1.BiomeModificationContext.GenerationSettingsContext context) {
            super(biome);
            this.context = context;
        }
        
        @Override
        public dev.architectury.hooks.level.biome.GenerationProperties.Mutable addFeature(GenerationStep.Feature decoration, RegistryEntry<PlacedFeature> feature) {
            Either<RegistryKey<PlacedFeature>, PlacedFeature> unwrap = feature.getKeyOrValue();
            if (unwrap.left().isPresent()) {
                this.context.addFeature(decoration, unwrap.left().get());
            } else {
                throw new UnsupportedOperationException("Cannot add a feature that is not registered: " + unwrap.right().orElseThrow());
            }
            return this;
        }
        
        @Override
        public dev.architectury.hooks.level.biome.GenerationProperties.Mutable addFeature(GenerationStep.Feature decoration, RegistryKey<PlacedFeature> feature) {
            this.context.addFeature(decoration, feature);
            return this;
        }
        
        @Override
        public dev.architectury.hooks.level.biome.GenerationProperties.Mutable addCarver(GenerationStep.Carver carving, RegistryEntry<ConfiguredCarver<?>> feature) {
            Either<RegistryKey<ConfiguredCarver<?>>, ConfiguredCarver<?>> unwrap = feature.getKeyOrValue();
            if (unwrap.left().isPresent()) {
                this.context.addCarver(carving, unwrap.left().get());
            } else {
                throw new UnsupportedOperationException("Cannot add a carver that is not registered: " + unwrap.right().orElseThrow());
            }
            return this;
        }
        
        @Override
        public dev.architectury.hooks.level.biome.GenerationProperties.Mutable addCarver(GenerationStep.Carver carving, RegistryKey<ConfiguredCarver<?>> feature) {
            this.context.addCarver(carving, feature);
            return this;
        }
        
        @Override
        public dev.architectury.hooks.level.biome.GenerationProperties.Mutable removeFeature(GenerationStep.Feature decoration, RegistryKey<PlacedFeature> feature) {
            context.removeFeature(decoration, feature);
            return this;
        }
        
        @Override
        public dev.architectury.hooks.level.biome.GenerationProperties.Mutable removeCarver(GenerationStep.Carver carving, RegistryKey<ConfiguredCarver<?>> feature) {
            context.removeCarver(carving, feature);
            return this;
        }
    }
    
    private static class MutableSpawnProperties extends BiomeHooks.SpawnSettingsWrapped implements SpawnProperties.Mutable {
        protected final net.fabricmc.fabric.api.biome.v1.BiomeModificationContext.SpawnSettingsContext context;
        
        public MutableSpawnProperties(Biome biome, net.fabricmc.fabric.api.biome.v1.BiomeModificationContext.SpawnSettingsContext context) {
            super(biome);
            this.context = context;
        }
        
        @Override
        public dev.architectury.hooks.level.biome.SpawnProperties.Mutable setCreatureProbability(float probability) {
            context.setCreatureSpawnProbability(probability);
            return this;
        }
        
        @Override
        public dev.architectury.hooks.level.biome.SpawnProperties.Mutable addSpawn(SpawnGroup category, SpawnSettings.SpawnEntry data) {
            context.addSpawn(category, data);
            return this;
        }
        
        @Override
        public boolean removeSpawns(BiPredicate<SpawnGroup, SpawnSettings.SpawnEntry> predicate) {
            return context.removeSpawns(predicate);
        }
        
        @Override
        public dev.architectury.hooks.level.biome.SpawnProperties.Mutable setSpawnCost(EntityType<?> entityType, SpawnSettings.SpawnDensity cost) {
            context.setSpawnCost(entityType, cost.mass(), cost.gravityLimit());
            return this;
        }
        
        @Override
        public dev.architectury.hooks.level.biome.SpawnProperties.Mutable setSpawnCost(EntityType<?> entityType, double charge, double energyBudget) {
            context.setSpawnCost(entityType, charge, energyBudget);
            return this;
        }
        
        @Override
        public dev.architectury.hooks.level.biome.SpawnProperties.Mutable clearSpawnCost(EntityType<?> entityType) {
            context.clearSpawnCost(entityType);
            return this;
        }
    }
    
    private static ClimateProperties.Mutable wrapWeather(Biome biome, WeatherContext context) {
        return new BiomeHooks.ClimateWrapped(biome) {
            @Override
            public ClimateProperties.Mutable setHasPrecipitation(boolean hasPrecipitation) {
                context.setPrecipitation(hasPrecipitation);
                return this;
            }
            
            @Override
            public ClimateProperties.Mutable setTemperature(float temperature) {
                context.setTemperature(temperature);
                return this;
            }
            
            @Override
            public ClimateProperties.Mutable setTemperatureModifier(TemperatureModifier temperatureModifier) {
                context.setTemperatureModifier(temperatureModifier);
                return this;
            }
            
            @Override
            public ClimateProperties.Mutable setDownfall(float downfall) {
                context.setDownfall(downfall);
                return this;
            }
        };
    }
    
    private static EffectsProperties.Mutable wrapEffects(Biome biome, EffectsContext context) {
        return new BiomeHooks.EffectsWrapped(biome) {
            @Override
            public EffectsProperties.Mutable setFogColor(int color) {
                context.setFogColor(color);
                return this;
            }
            
            @Override
            public EffectsProperties.Mutable setWaterColor(int color) {
                context.setWaterColor(color);
                return this;
            }
            
            @Override
            public EffectsProperties.Mutable setWaterFogColor(int color) {
                context.setWaterFogColor(color);
                return this;
            }
            
            @Override
            public EffectsProperties.Mutable setSkyColor(int color) {
                context.setSkyColor(color);
                return this;
            }
            
            @Override
            public EffectsProperties.Mutable setFoliageColorOverride(@Nullable Integer colorOverride) {
                context.setFoliageColor(Optional.ofNullable(colorOverride));
                return this;
            }
            
            @Override
            public EffectsProperties.Mutable setGrassColorOverride(@Nullable Integer colorOverride) {
                context.setGrassColor(Optional.ofNullable(colorOverride));
                return this;
            }
            
            @Override
            public EffectsProperties.Mutable setGrassColorModifier(GrassColorModifier modifier) {
                context.setGrassColorModifier(modifier);
                return this;
            }
            
            @Override
            public EffectsProperties.Mutable setAmbientParticle(@Nullable BiomeParticleConfig settings) {
                context.setParticleConfig(Optional.ofNullable(settings));
                return this;
            }
            
            @Override
            public EffectsProperties.Mutable setAmbientLoopSound(@Nullable RegistryEntry<SoundEvent> sound) {
                context.setAmbientSound(Optional.ofNullable(sound));
                return this;
            }
            
            @Override
            public EffectsProperties.Mutable setAmbientMoodSound(@Nullable BiomeMoodSound settings) {
                context.setMoodSound(Optional.ofNullable(settings));
                return this;
            }
            
            @Override
            public EffectsProperties.Mutable setAmbientAdditionsSound(@Nullable BiomeAdditionsSound settings) {
                context.setAdditionsSound(Optional.ofNullable(settings));
                return this;
            }
            
            @Override
            public EffectsProperties.Mutable setBackgroundMusic(@Nullable MusicSound music) {
                context.setMusic(Optional.ofNullable(music));
                return this;
            }
        };
    }
    
}

